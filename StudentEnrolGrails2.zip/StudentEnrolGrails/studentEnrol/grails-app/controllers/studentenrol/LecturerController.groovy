package studentenrol

class LecturerController {

    static scaffold = Lecturer

}
