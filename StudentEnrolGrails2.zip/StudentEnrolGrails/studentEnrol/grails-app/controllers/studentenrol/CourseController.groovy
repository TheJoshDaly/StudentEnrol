package studentenrol

class CourseController {

    static scaffold = Course

}
