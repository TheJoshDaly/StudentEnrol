package studentenrol

class ModuleController {

    static scaffold = Module

}
