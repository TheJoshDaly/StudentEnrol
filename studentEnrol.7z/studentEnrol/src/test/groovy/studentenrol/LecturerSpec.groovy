package studentenrol

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class LecturerSpec extends Specification implements DomainUnitTest<Lecturer> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
