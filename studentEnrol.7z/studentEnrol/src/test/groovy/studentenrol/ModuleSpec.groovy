package studentenrol

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class ModuleSpec extends Specification implements DomainUnitTest<Module> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
