package studentenrol

class CourseController {

    def index() { }
}
