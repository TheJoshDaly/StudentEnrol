package studentenrol

class Course {

	def department;
	def courseTitle;
	def courseLeader;
	def courseCode;
	def startDate;
	def endDate;
	def description;
	int number;
	double tuitionFees;

    static constraints = {
    }
}
