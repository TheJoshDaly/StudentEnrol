package studentenrol

class BootStrap {

    def init = { servletContext ->

def tonderai = new Lecturer(
	fullName: 'Tonderai Maswera',
	post: 'Lecturer',
	subject: 'Computing',
	lecturerEmail: 'acesm1@my.shu.ac.uk',
	office: 'Leningrad',
	bio: 'You will learn, or you will die!'
).save()

def matthew = new Lecturer(
	fullName: 'Matthew Love',
	post: 'Full-Time Weirdo',
	subject: 'Computing',
	lecturerEmail: 'weirdo@my.shu.ac.uk',
	office: 'Prison',
	bio: 'Never be in a room alone with him'
).save()

def computing = new Course (
department: 'Computing',
courseCode: 'CS123',
courseTitle: 'BSc Hon Computing',
courseLeader: matthew,
startDate: new Date('09/09/2019'),
endDate: new Date('07/07/2023'),
numberOfStudents: 55,
studyMode: 'Fulltime',
tuitionFees: 9000.60,
description: 'Lorem Ipsum').save()

def gamesdesign = new Course (
department: 'Computing',
courseCode: 'CS124',
courseTitle: 'BSc Games Design',
courseLeader: tonderai,
startDate: new Date('09/09/2019'),
endDate: new Date('07/07/2023'),
numberOfStudents: 55,
studyMode: 'Fulltime',
tuitionFees: 9000.60,
description: 'Lorem Ipsum').save()

def threeddesign = new Course (
department: 'Computing',
courseCode: 'CS125',
courseTitle: 'BSc 3D Design',
courseLeader: tonderai,
startDate: new Date('09/09/2019'),
endDate: new Date('07/07/2023'),
numberOfStudents: '55',
studyMode: 'Fulltime',
tuitionFees: '9000.60',
description: 'Lorem Ipsum').save()

def josh = new Student (
studentName: 'Josh Daly',
studentID: 'b7034015',
dob: new Date('13/10/1998'),
isFundingAvailable: false,
studentEmail: 'b7034015@my.shu.ac.uk',
studentUsername: 'JoshDaly',
studentPassword: 'milesisasoyboy',
course: computing).save()

def miles = new Student (
studentName: 'Miles',
studentID: 'b7034015',
dob: new Date('13/10/1998'),
isFundingAvailable: false,
studentEmail: 'b7034015@my.shu.ac.uk',
studentUsername: 'MWaring',
studentPassword: 'milesisasoyboy',
course: computing).save()

def webdev = new Module(
module_title: 'Web Application Design and Implementation',
module_code: 'M123',
credits: '20',
lecturer: 'Tonderai Masweri',
description: 'This teaches you about web applications and building them'
).save()

def sysarchs = new Module(
module_title: 'Systems Architectures',
module_code: 'M124',
credits: '20',
lecturer: 'Josh Daly',
description: 'This teaches you about Systems Architectures'
).save()

tonderai.addToCourses(computing)
matthew.addToCourses(gamesdesign)

computing.addToModules(webdev)
gamesdesign.addToModules(sysarchs)

tonderai.addToModules(webdev)
matthew.addToModules(sysarchs)

computing.addToLecturers(tonderai)
gamesdesign.addToLecturers(matthew)

josh.addToModules(webdev)
miles.addToModules(sysarchs)

computing.addToStudents(josh)
gamesdesign.addToStudents(miles)

    }
    def destroy = {
    }
}
