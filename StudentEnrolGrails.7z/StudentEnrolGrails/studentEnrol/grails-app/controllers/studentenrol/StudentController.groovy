package studentenrol

class StudentController {

    static scaffold = Student

}
